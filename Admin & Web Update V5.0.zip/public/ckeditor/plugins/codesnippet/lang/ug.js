﻿/*
 Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","ug",{button:"كود پارچىسى قىستۇرۇش",codeContents:"كود مەزمۇنى",emptySnippetError:"كود پارچىسى بوش قالمايدۇ",language:"تىل",title:"كود پارچىسى",pathName:"كود پارچىسى"});